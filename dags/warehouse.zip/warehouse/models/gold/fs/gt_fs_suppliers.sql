{{ config(
    materialized='incremental',
    unique_key='sk_fs_supplier',
    incremental_strategy='delete+insert',
    alias='gt_fs_suppliers',
    post_hook="{{update_statistics(this,'SupplierStatistics','sk_fs_supplier')}}"
) }}


WITH snapshot_table AS (
	SELECT 
        HASHBYTES('SHA2_256',{{ dbt_utils.generate_surrogate_key(['driving.source_businesskey', 'driving.source_system', 'driving.dbt_valid_from']) }}) AS sk_fs_supplier,
        HASHBYTES('SHA2_256',{{ dbt_utils.generate_surrogate_key(['driving.source_businesskey', 'driving.source_system']) }}) AS sk_fs_supplier_master,
        driving.source_system AS dbt_id_sourcesystem,
        driving.source_businesskey AS dbt_id_business_key,
        CAST(
            CASE 
                WHEN driving.dbt_valid_to IS NULL THEN 1
                ELSE 0
            END AS BIT) AS dbt_current_flag,
        CAST(driving.dbt_valid_from AS DATE) AS dbt_valid_from,
        CAST(COALESCE(driving.dbt_valid_to, '3000-12-31') AS DATE) AS dbt_valid_to,
        CAST(driving.dbt_valid_from AS DATE) AS mod_valid_from, 
        CAST(CASE
                WHEN driving.dbt_valid_to IS NULL 
                THEN '3000-12-31'
             ELSE DATEADD(DAY, -1, driving.dbt_valid_to)
        END AS DATE) AS mod_valid_to,
		CAST(driving.dbt_updated_at AS DATE) AS dbt_updated_at,
        SupplierName,
        PhoneNumber,
        Email
	FROM {{ ref('st_fs_suppliers') }} driving
    WHERE 1=1
    {% if is_incremental() %}
        AND driving.dbt_updated_at > (
        SELECT MAX(dbt_updated_at)
        FROM {{ this }}
        WHERE dbt_id_business_key != -1
        )
    {% endif %}

    UNION ALL

	SELECT 
        -- dummy record for artifical foreign keys
        -1  AS sk_fs_supplier,
        -1  AS sk_fs_supplier_master,
        'N/A'  AS dbt_id_sourcesystem,
        -1  AS dbt_id_business_key,
        1  AS dbt_current_flag,
        CAST('1900-01-01' AS DATE) AS dbt_valid_from,
        CAST('3000-12-31' AS DATE) AS dbt_valid_to,
        CAST('1900-01-01' AS DATE) AS mod_valid_from,
        CAST('3000-12-31' AS DATE) AS mod_valid_to,
		CAST('1900-01-01' AS DATE) AS dbt_updated_at,
        'N/A' AS SupplierName,
        'N/A' AS PhoneNumber,
        'N/A' AS Email
)
SELECT 
    
        sk_fs_supplier,
        sk_fs_supplier_master,
        dbt_id_sourcesystem,
        dbt_id_business_key,
        dbt_current_flag,
        dbt_valid_from,
        dbt_valid_to,
        mod_valid_from,
        mod_valid_to,
        dbt_updated_at,
        SupplierName,
        PhoneNumber,
        Email
FROM snapshot_table
WHERE 1=1